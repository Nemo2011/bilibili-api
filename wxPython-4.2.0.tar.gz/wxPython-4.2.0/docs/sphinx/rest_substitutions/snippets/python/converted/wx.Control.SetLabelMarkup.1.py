
                text = wx.StaticText(self, -1, 'Hello world!')

                # Some more code...
                text.SetLabelMarkup("<b>&ampBed</b> &ampmp "
                                     "<span foreground='red'>breakfast</span> "
                                     "available <big>HERE</big>")
