
                image.SetOption(wx.IMAGE_OPTION_CUR_HOTSPOT_X, hotSpotX)
                image.SetOption(wx.IMAGE_OPTION_CUR_HOTSPOT_X, hotSpotY)
