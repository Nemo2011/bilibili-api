
    if self.GetAnchor("index.htm#chapter2") == "chapter2":
        DoSomething()


