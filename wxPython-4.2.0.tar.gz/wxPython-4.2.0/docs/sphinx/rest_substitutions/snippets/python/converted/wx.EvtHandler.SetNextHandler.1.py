
                      handlerA.SetNextHandler(handlerB)
                      handlerB.SetPreviousHandler(handlerA)
