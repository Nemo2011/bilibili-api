
            def CanOpen(self, location):

                return self.GetProtocol(location) == "http"

