
    if self.GetLeftLocation("file:myzipfile.zip#zip:index.htm") == "file:myzipfile.zip":
        DoSomething()

