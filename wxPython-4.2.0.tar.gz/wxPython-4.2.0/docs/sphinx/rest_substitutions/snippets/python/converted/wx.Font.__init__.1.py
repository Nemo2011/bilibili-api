    # Create a font using wx.FontInfo
    font = wx.Font( wx.FontInfo(10).Bold().Underline() )
