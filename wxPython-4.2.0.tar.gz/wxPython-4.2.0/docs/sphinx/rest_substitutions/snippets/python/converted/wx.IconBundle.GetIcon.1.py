
     GetIcon(wx.Size(size, size))
