
    # RC resources are not supported in wxPython
