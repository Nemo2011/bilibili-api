
    if self.GetRightLocation("file:myzipfile.zip#zip:index.htm") == "index.htm":
        ReadHTML(filename)
