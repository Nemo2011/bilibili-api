
    # GetSizeFromText is a simpler way to do this:
    size = self.GetSizeFromTextSize(self.GetTextExtent(text).GetWidth())
