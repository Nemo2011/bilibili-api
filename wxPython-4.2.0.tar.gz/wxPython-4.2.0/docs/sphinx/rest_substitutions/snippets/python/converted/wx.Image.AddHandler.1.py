
                wx.Image.AddHandler(wx.PNGHandler)
