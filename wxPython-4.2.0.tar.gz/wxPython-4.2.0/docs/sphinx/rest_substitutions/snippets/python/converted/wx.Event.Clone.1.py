
            def Clone(self):

                return MyEvent()
