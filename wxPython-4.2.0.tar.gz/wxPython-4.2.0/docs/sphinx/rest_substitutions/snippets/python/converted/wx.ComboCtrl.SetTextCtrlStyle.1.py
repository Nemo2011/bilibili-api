
                comboCtrl = wx.ComboCtrl()

                # Let's make the text right-aligned
                comboCtrl.SetTextCtrlStyle(wx.TE_RIGHT)

                comboCtrl.Create(parent, wx.ID_ANY, "")
