
            #                                   | self.11  self.12   0 |
            # dist' = | src.self.x  src._my  0 | x | self.21  self.22   0 |
            #                                   | self.tx  self.ty   1 |
