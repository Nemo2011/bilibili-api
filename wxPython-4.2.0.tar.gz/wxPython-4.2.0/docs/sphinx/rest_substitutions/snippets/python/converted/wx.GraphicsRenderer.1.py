
        path = wx.GraphicsPath() # from somewhere
        brush = path.GetRenderer().CreateBrush(wx.BLACK_BRUSH)
