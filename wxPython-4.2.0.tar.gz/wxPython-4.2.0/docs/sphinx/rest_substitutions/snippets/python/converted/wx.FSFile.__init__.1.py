
            class MyFSFile(wx.FSFile):

                def __init__(self):

                    wx.FSFile.__init__(self)


