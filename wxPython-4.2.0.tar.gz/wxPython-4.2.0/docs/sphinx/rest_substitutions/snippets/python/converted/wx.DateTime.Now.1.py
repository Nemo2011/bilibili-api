
            now = wx.DateTime.Now()
            print "Current time in Paris:\t%s\n"%(now.Format("%c", wx.DateTime.CET))
