
        self.ShowColumn(idx, False)
