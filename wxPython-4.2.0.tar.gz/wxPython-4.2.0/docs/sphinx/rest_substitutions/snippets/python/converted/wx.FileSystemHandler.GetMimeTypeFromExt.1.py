
            if GetMimeTypeFromExt("index.htm") == "text/html":
                wx.MessageBox("Is HTML!")
