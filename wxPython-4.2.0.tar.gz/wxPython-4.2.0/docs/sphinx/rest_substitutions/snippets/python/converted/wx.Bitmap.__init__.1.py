
            newBitmap = oldBitmap.GetSubBitmap(
                                  wx.Rect(0, 0, oldBitmap.GetWidth(), oldBitmap.GetHeight()))
