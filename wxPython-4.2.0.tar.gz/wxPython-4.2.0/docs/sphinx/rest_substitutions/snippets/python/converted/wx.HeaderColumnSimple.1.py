
            header = wx.HeaderCtrlSimple()   # Fill in the constructor
            col = wx.HeaderColumnSimple("Title")
            col.SetWidth(100)
            col.SetSortable(100)
            header.AppendColumn(col)
