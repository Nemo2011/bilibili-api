    
    # matrix = t * matrix
