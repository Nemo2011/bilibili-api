
            self.help.SetViewer("kdehelp")
            self.help.SetViewer("gnome-help-browser")
            self.help.SetViewer("netscape", wx.HELP_NETSCAPE)
