
            dlg = wx.DirDialog (None, "Choose input directory", "",
                                wx.DD_DEFAULT_STYLE | wx.DD_DIR_MUST_EXIST)

