
    font = wx.Font(wx.FontInfo(12).FaceName("Helvetica").Italic())
