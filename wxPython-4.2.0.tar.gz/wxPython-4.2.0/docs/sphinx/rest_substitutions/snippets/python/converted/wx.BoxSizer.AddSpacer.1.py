
            if boxSizer.IsVertical():

                boxSizer.Add(0, size, 0)

            else:

                boxSizer.Add(size, 0, 0)

