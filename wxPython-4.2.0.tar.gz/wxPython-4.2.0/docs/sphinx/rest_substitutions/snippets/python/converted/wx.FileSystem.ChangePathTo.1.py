
            ChangePathTo("dir/subdir/xh.htm")
            ChangePathTo("dir/subdir", True)
            ChangePathTo("dir/subdir/", True)
