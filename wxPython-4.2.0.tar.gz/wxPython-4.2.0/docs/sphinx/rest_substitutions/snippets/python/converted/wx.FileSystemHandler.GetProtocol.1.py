
    if self.GetProtocol("file:myzipfile.zip#zip:index.htm") == "zip":
        UnzipFile(filename)
